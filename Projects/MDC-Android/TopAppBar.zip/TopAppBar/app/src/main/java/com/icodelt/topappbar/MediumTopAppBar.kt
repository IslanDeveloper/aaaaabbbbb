package com.icodelt.topappbar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar

class MediumTopAppBar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medium_top_app_bar)

        val topAppBar = findViewById<MaterialToolbar>(R.id.topAppBar)

        topAppBar.setNavigationOnClickListener{
            Snackbar.make(topAppBar, "Navigation icon clicked!", Snackbar.LENGTH_SHORT).show()
        }

        topAppBar.setOnMenuItemClickListener { menuItem ->
            when(menuItem.itemId){

                R.id.favorite -> {
                    Snackbar.make(topAppBar, "Favorite clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                R.id.more -> {
                    Snackbar.make(topAppBar, "More clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }
    }
}