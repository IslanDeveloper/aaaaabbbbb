package com.icodelt.topappbar

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.snackbar.Snackbar

class ContextualActionBar : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_contextual_action_bar)

        val topAppBar = findViewById<MaterialToolbar>(R.id.topAppBar)

        topAppBar.setNavigationOnClickListener{
            Snackbar.make(topAppBar, "Navigation icon clicked!", Snackbar.LENGTH_SHORT).show()
        }

        topAppBar.setOnMenuItemClickListener { menuItem ->
            when(menuItem.itemId){
                R.id.edit -> {
                    Snackbar.make(topAppBar, "Edit clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                R.id.favorite -> {
                    Snackbar.make(topAppBar, "Favorite clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                R.id.more -> {
                    Snackbar.make(topAppBar, "More clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }

        val callback = object : ActionMode.Callback {

            override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                menuInflater.inflate(R.menu.contextual_action_bar, menu)
                return true
            }

            override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
                return when (item?.itemId) {
                    R.id.share -> {
                        Snackbar.make(topAppBar, "Share clicked!", Snackbar.LENGTH_SHORT).show()
                        true
                    }
                    R.id.delete -> {
                        Snackbar.make(topAppBar, "Delete clicked!", Snackbar.LENGTH_SHORT).show()
                        true
                    }
                    R.id.more -> {
                        Snackbar.make(topAppBar, "More clicked!", Snackbar.LENGTH_SHORT).show()
                        true
                    }
                    else -> false
                }
            }

            override fun onDestroyActionMode(mode: ActionMode?) {
            }
        }

        val actionMode = startSupportActionMode(callback)
        actionMode?.title = "1 selected"
    }
}