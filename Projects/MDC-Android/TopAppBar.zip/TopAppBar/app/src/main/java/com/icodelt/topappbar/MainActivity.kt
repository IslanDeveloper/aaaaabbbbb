package com.icodelt.topappbar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.shape.MaterialShapeDrawable
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val topAppBar = findViewById<MaterialToolbar>(R.id.topAppBar)
        val buttonCenterAlignedTopAppBar = findViewById<MaterialButton>(R.id.buttonCenterAppBar)
        val buttonMediumTopAppBar = findViewById<MaterialButton>(R.id.buttonMediumAppBar)
        val buttonLargeTopAppBar = findViewById<MaterialButton>(R.id.buttonLargeAppBar)
        val buttonImageLargeTopAppBar = findViewById<MaterialButton>(R.id.buttonImageLargeAppBar)
        val buttonContextualActionBar = findViewById<MaterialButton>(R.id.buttonContextualActionBar)

        topAppBar.setNavigationOnClickListener{
            Snackbar.make(topAppBar, "Navigation icon clicked!", Snackbar.LENGTH_SHORT).show()
        }

        topAppBar.setOnMenuItemClickListener { menuItem ->
            when(menuItem.itemId){
                R.id.edit -> {
                    Snackbar.make(topAppBar, "Edit clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                R.id.favorite -> {
                    Snackbar.make(topAppBar, "Favorite clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                R.id.more -> {
                    Snackbar.make(topAppBar, "More clicked!", Snackbar.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }

        buttonCenterAlignedTopAppBar.setOnClickListener {
            val intent = Intent(this, CenterAlignedTopAppBar::class.java)
            startActivity(intent)
        }

        buttonMediumTopAppBar.setOnClickListener {
            val intent = Intent(this, MediumTopAppBar::class.java)
            startActivity(intent)
        }

        buttonLargeTopAppBar.setOnClickListener {
            val intent = Intent(this, LargeTopAppBar::class.java)
            startActivity(intent)
        }

        buttonImageLargeTopAppBar.setOnClickListener {
            val intent = Intent(this, ImageLargeTopAppBar::class.java)
            startActivity(intent)
        }

        buttonContextualActionBar.setOnClickListener {
            val intent = Intent(this, ContextualActionBar::class.java)
            startActivity(intent)
        }
    }
}