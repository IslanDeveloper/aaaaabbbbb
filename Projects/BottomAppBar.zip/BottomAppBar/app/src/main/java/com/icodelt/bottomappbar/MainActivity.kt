package com.icodelt.bottomappbar

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomappbar.BottomAppBar
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val bottomAppBar = findViewById<BottomAppBar>(R.id.bottomAppBar)
        val fab = findViewById<FloatingActionButton>(R.id.fab)

        bottomAppBar.setNavigationOnClickListener {
            Toast.makeText(applicationContext, "Navigation icon clicked!", Toast.LENGTH_SHORT).show()
        }

        bottomAppBar.setOnMenuItemClickListener {menuItem ->
            when(menuItem.itemId){
                R.id.accelerator -> {
                    Toast.makeText(applicationContext, "Add Photo clicked!", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.rotation -> {
                    Toast.makeText(applicationContext, "Rotation clicked!", Toast.LENGTH_SHORT).show()
                    true
                }
                R.id.dashboard -> {
                    Toast.makeText(applicationContext, "Dashboard clicked!", Toast.LENGTH_SHORT).show()
                    true
                }

                else -> false
            }
        }

        fab.setOnClickListener {
            Toast.makeText(applicationContext, "FAB clicked!", Toast.LENGTH_SHORT).show()
        }
    }
}